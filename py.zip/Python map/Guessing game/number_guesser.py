import random
import time



#import time och random gör så vi kan få random number och kan sätta tid på coden

n = random.randint(1, 10)


#f = open är att man öppnar en fil vilket i detta fallet är guess.txt och appendar alltså lägger till det man vill med f.write i txt filen, använder man w så skriver den något men det försvinner 
# efter du kör coden igen

f = open("guess.txt", "a+")



print ("I am thinking of a Number between 1 and 10")

running = True
while running:
    guess_str = input("Take a Guess")
    guess = int(guess_str)
    if guess == n:
        f.write("Nummer som gissades " + str(guess) + "\n")
        f.close()
        print("Well done")
        time.sleep(5)
        running = False
    elif guess < n:
        print("Try a bigger number")
    else:
        print("Try a smaller Number")



# running är när programmer körs, guess = int gör så att våran guess_str blir ett number aka en int

# time sleep är för delay så inte programmet stängs av direkt

#elif och else är ifall man får fel, t.ex för litet elr stort number

