import random
import time



n = input("Välj ett nummer mellan 0 och 9")

nu = random.randint(10, 100)


print(str(n) + str(nu) + str(n))

time.sleep(5)
 
