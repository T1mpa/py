import random
import time


print("Welcome To Your Password Generator")

chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'

number = input("Amont of password to generate: ")
number = int(number)

lenght = input("Input Your Passwords Length")
lenght = int(lenght)

print("\nhere are your passwords: ")

for pwd in range(number):
    passwords = ''
    for c in range(lenght):
        passwords += random.choice(chars)

    print(passwords)


time.sleep(20)




