import random
import time


chars = "abcdefghijklmnopqrstuvwxyz0123456789"
chars_list = list(chars)

password = input("Enter a password : ")

start = time.time()



guess_password = ""


win = 1



while(guess_password != password):
    guess_password = random.choices(chars_list, k=len(password))
    

    print("<=============="+ str(guess_password)+ "==============>")

    if(guess_password == list(password)):
        print(" Your password is : "+ "".join(guess_password) ,"Your attemps : " + str(win))
        break
    elif guess_password != password:
        win += 1
        

end = time.time()

print(end - start)


#Ska försöka göra så man kan se hur många attemps som gjordes och så att crackers in uppreppar sig dvs den gissar 1 fler gångar 
#Ska även försöka göra så att jag kan få in alla tider i ett doc och ordna dem i hur långt lösenordet var och sedan få ut ett medelvärde

#end är när koden är slut och start är när den börjar

#sätt start där man vill att den ska börja ta ditt i detta fallet efter man valt nummer och end där det ska sluta

#Det funkar så att start är tiden den börjar och end är vilken tid den slutade
# t.ex börjar start vid 13:00 och slutar 13:01 så tar den 13:01 - 13:00 och så får den en minut, så det är inte riktigt en timer utan time.time() håller koll när koden börjar och slutar


time.sleep(10)